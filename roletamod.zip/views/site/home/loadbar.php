<div class="loading-bar wrapper container">
    <div class="buttons row">
        <div class="col-12 text-center">
            <!-- <input type="submit" value="CONTINUAR" class="rounded-pill d-none btn-save" style="display:inline-block; line-height:1.5; text-align:center; text-decoration:none; vertical-align:middle; cursor:pointer; font-size:1rem; width:51%; margin-top: 9px; font-weight: 700; text-transform: uppercase; text-shadow: 0 0 2px rgb(0 0 0 / 80%); padding: 13px; background-color: #16b763; color: #fff; border-radius: 15px 15px 15px 15px; box-shadow: 0 -1px 24px 0 #16b763; border:1px solid transparent"> -->


        </div>
    </div>
    <section>

        <ol class="progress-bar">
            <li id="badge1" class="is-active font-black"> <p class="progress-text text-left font-black" style="text-align: left">GIRE</p></li>
            <li id="badge2" class="font-black"><p class="progress-text text-center font-black">CADASTRE</p></li>
            <li id="badge3" class="font-black"><p class="progress-text font-black">VERIFIQUE SEU E-MAIL</p></li>
        </ol>
    </section>

</div>