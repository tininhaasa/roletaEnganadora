<section class="intro part1" id="intro1-section">
	<div class="cta">
		<h1 class="main-headline">
			GANHE UM <span style="color: #FDD500">SUPER PRÊMIO</span> EM QUATRO
			PASSOS! <span style="color: #FDD500">GIRE PARA GANHAR!</span>
		</h1>
	</div>
	<div class="roulette">
		<!-- <img src="./src/img/Iluminação-min.webp" id="roleta1" /> -->
		<div id="roleta2">
			<img src="<?= $url ?>/assets/img/roleta-2.png" class="spinner">
		</div>
		<img src="<?= $url ?>/assets/img/button-gire.webp" id="roleta3" class="runSpin">
	</div>
	<div class="button-roulette">
		<button id="button-cta" class="runSpin btn-redirect">
			GIRE PARA GANHAR
		</button>
	</div>

	<!-- <div>
          <img src="./src/img/btn-click.png" alt="">
        </div> -->
</section>