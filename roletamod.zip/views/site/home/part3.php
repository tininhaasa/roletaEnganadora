<section class="intro part3" id="intro3-section">

    <div class="content text-center mb-2">
        <img src="<?= $url ?>/assets/img/presente-1.png" class="gift" alt="">
        <h2 class="text-center font-regular"><b class="text-warning">Verifique o seu e-mail e Whatsapp</b> <br>
            <b>pois te enviei uma surpresa bônus</b></h2>
    </div>
            <div class="loading">
                <p class="text-center">Você será direcionado em <strong class="counter">5</strong> segundos </p>
                <div class="progress" style="margin-bottom:20px" role="progressbar" aria-label="Basic example" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                    <div class="progress-bar" height="16px" style="height: 16px;"></div>
                </div>
            </div>

</section>