<?php

/**
*
* Arquivo onde são definidos os helpers
*
* 
*
**/

define('LOCAL_URL', '/roletamod/');

return array(
	'URLHelper' => new URLHelper(),
);